# template-project

Template project for Spring boot application.


Running Application
------------
1. Run in your favorite IDE:
    - run the following file [BackendTechAssessmentApplication](src/main/java/org/megro/TemplateApplication.java)
2. Run in terminal:
    - in the project root directory, execute the following command: `mvn spring-boot:run`