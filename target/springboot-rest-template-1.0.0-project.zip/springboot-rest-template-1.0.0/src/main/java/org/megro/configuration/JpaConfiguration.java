package org.megro.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * Created by mbach1 on 4/11/18.
 */
@Configuration
@EnableJpaAuditing
public class JpaConfiguration {

}
