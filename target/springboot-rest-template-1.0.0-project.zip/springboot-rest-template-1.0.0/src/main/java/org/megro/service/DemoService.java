package org.megro.service;

import org.springframework.stereotype.Service;

@Service
public class DemoService {

}