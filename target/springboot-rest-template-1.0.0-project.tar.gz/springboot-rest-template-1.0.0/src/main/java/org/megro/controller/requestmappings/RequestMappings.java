package org.megro.controller.requestmappings;

public class RequestMappings {

}
